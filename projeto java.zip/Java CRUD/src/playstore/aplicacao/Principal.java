package playstore.aplicacao;
import java.util.List;
import java.util.Scanner;
import playstore.DAO.ClienteDao;
import playstore.DAO.JogoDao;
import playstore.model.Cliente;
import playstore.model.Jogo;

public class Principal {
	
	public static void main(String[] args) {
		ClienteDao clienteDao = new ClienteDao();
		JogoDao jogoDao = new JogoDao();
		Scanner ler = new Scanner(System.in);
		
		System.out.println("Digite [0] para acessar como cliente\nDigite [1] para acessar como Funcionario");
		int acesso = ler.nextInt();
		
		//Cliente
		if(acesso == 0) {
			System.out.println("Digite seu nome =");
			ler.nextLine();
			String nome = ler.nextLine();
			System.out.println("Digite sua Idade =");
			int idade = ler.nextInt();
			System.out.println("Digite a quantidade de dinheiro que tem na sua conta =");
			double dinheiroNaConta = ler.nextDouble();
			Cliente cliente = new Cliente(nome, idade, dinheiroNaConta);
			int id = clienteDao.save(cliente);
			cliente.setId(id);
			List<Jogo> jogos = jogoDao.getJogos();
			
			int menu = 0;
			while (menu != 1) {
				System.out.println("\nDigite [0] para ver o catalogo de jogos\nDigite [1] para sair do programa");
				int numeroDigitado = ler.nextInt();
				if(numeroDigitado == 0) {
					System.out.println ("\n-----------CATALOGO DE JOGOS-----------");
					for(Jogo j : jogos) {
						System.out.println("ID= " + j.getId() + " || Nome= " + j.getNome() + " || Preco= " + j.getPreco());
					}
				}
				if(numeroDigitado == 1) {
					System.exit(0);
				}
				System.out.println("\nDigite o ID do jogo para compra-lo");
				int jogoEscolhidoId = ler.nextInt();					
				for(Jogo j : jogos) {
					if (j.getId() == jogoEscolhidoId) {						
						Jogo jogoEscolhido = j;

						if(cliente.getDinheiroNaConta() >= j.getPreco()) {
							cliente.comprar(jogoEscolhido);
							clienteDao.update(cliente);			
							System.out.println("Compra feita com sucesso! Novo dinheiro na conta = " + cliente.getDinheiroNaConta());						
						}
						else {
							System.out.println("Dinheiro insuficiente!");
						}	
					}
				}
			}
		}
					
					
			
			
		//funcionario
		if(acesso == 1) {
			System.out.println("Digite a senha para entrar como funcionario:");
			int senha = ler.nextInt();
			if(senha == 12345) {
				System.out.println("Senha correta");
				int menu = 0;
				while(menu != 1) {
				System.out.println("\nDigite [1] para adicionar um jogo na loja\nDigite [2] para ver os jogos disponiveis\nDigite [3] para atualizar algum jogo\nDigite [4] "
				+ "para deletar algum jogo\nDigite [5] para ver os clientes cadastrados\nDigite [6] para sair do programa");
				int numeroDig = ler.nextInt();
					if(numeroDig == 1) {
						int id = 0;
						System.out.println("Digite o nome= ");
						ler.nextLine();
						String nome = ler.nextLine();
						System.out.println("Digite o preco= ");
						double preco = ler.nextDouble();
						Jogo jogo = new Jogo(id, nome, preco);
						jogoDao.save(jogo);
						System.out.println("Jogo adicionado com sucesso!");
					}
					if(numeroDig == 2) {
						System.out.println();
						for(Jogo j : jogoDao.getJogos()) {
							System.out.println("ID= " + j.getId() + " || Nome= " + j.getNome() + " || Preco= " + j.getPreco());
						}
					}
					if(numeroDig == 3) {
						System.out.println("Atualizar jogo (selecionar por ID)");
						System.out.println("Digite ID= ");
						int id = ler.nextInt();
						System.out.println("Digite o nome= ");
						ler.nextLine();
						String nome = ler.nextLine();
						System.out.println("Digite o Preco= ");
						double preco = ler.nextDouble();
						Jogo jogoAtt = new Jogo(id, nome, preco);
						jogoDao.update(jogoAtt);
						System.out.println("Jogo atualizado com sucesso!");
					}
					if(numeroDig == 4) {
						System.out.println("Digite o ID do jogo para deleta-lo");
						int id = ler.nextInt();
						
						jogoDao.deleteByID(id);
						System.out.println("jogo deletado com sucesso!");
					}
					if(numeroDig == 5) {
						for(Cliente c : clienteDao.getClientes()) {
						System.out.println("ID= " + c.getId() + " || Nome= " + c.getNome());
						}
					}
					if(numeroDig == 6) {
						System.exit(0);
					}
				}
			}			
		}
		ler.close();
	}
}			
