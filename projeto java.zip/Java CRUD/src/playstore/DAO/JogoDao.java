package playstore.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import playstore.factory.ConnectionFactory;
import playstore.model.Jogo;

public class JogoDao {

	public void save(Jogo jogo) {
		String sql = "INSERT INTO jogo(nome, preco) VALUES (?, ?)";
		
		Connection conn = null;
		PreparedStatement pstm = null;
		
		try {
			//Criar uma conexao com o banco de dados
			conn = ConnectionFactory.createConnectiontoMySQL();
			
			//PreparedStatement criada para executar uma query
			pstm = (PreparedStatement) conn.prepareStatement(sql);
			//adicionar os valores que sao esperados pela query
			pstm.setString(1, jogo.getNome());
			pstm.setDouble(2, jogo.getPreco());
		
			//Executar a query
			pstm.execute();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				if(pstm != null) {
					pstm.close();
				}
				if(conn != null) {
					conn.close();
				}
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public List<Jogo> getJogos(){
		String sql = "SELECT * FROM jogo";
		
		List<Jogo> jogos = new ArrayList<Jogo>();
		
		Connection conn = null;
		PreparedStatement pstm = null;
		//Classe que vai recuperar os dados do banco. *SELECT*
		ResultSet rset = null;
		
		try {
			conn = ConnectionFactory.createConnectiontoMySQL();
			
			pstm = (PreparedStatement) conn.prepareStatement(sql);
			
			rset = pstm.executeQuery();
		
			while(rset.next()) {
				Jogo jogo = new Jogo(0, sql, 0);
			
				//Recuperar o id
				jogo.setId(rset.getInt("id"));
				//Recuperar o nome
				jogo.setNome(rset.getString("nome"));
				//Recuperar o preco
				jogo.setPreco(rset.getFloat("preco"));
			
				jogos.add(jogo);
			
			
			
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally {
			try {
				if(rset != null) {
					rset.close();
				}
				if(pstm != null) {
					pstm.close();
				}
				if(conn != null) {
					conn.close();
				}
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		
		}
		return jogos;
	}		
		
	public void update(Jogo jogo) {
	String sql = "UPDATE jogo SET nome = ?, preco = ?" + " WHERE id = ?";
		
		Connection conn = null;
		PreparedStatement pstm = null;
		
		try {
			//tenta Criar conexao com o banco
			conn = ConnectionFactory.createConnectiontoMySQL();
			
			//tenta Criar a classe para executar a query
			pstm = (PreparedStatement) conn.prepareStatement(sql);
			
			//Adicionar os valores para atualizar
			pstm.setString(1, jogo.getNome());
			pstm.setDouble(2, jogo.getPreco());
			//Qual o ID do registro que deseja atualizar?
			pstm.setInt(3, jogo.getId());
		
			//Executar a query
			pstm.execute();
		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				if(pstm != null){
					pstm.close();
				}
				if(conn != null) {
					conn.close();
				}
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public void deleteByID(int id) {
		String sql = "DELETE FROM jogo WHERE id = ?";
		
		Connection conn = null;
		PreparedStatement pstm = null;
		
		try {
			conn = ConnectionFactory.createConnectiontoMySQL();
			pstm = conn.prepareStatement(sql);
			
			pstm.setInt(1, id);
			
			pstm.execute();			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				if(pstm != null) {
					pstm.close();
				}
				if(conn != null) {
					conn.close();
				}
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		}
	}

}
