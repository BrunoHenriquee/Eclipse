package playstore.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import playstore.factory.ConnectionFactory;
import playstore.model.Cliente;

public class ClienteDao {
	
	public int save(Cliente cliente) {
		String sql = "INSERT INTO cliente(nome, idade, dinheiroNaConta) VALUES (?, ?, ?)";
		
		Connection conn = null;
		PreparedStatement pstm = null;
        int id = 0;
		
		try {
			//Criar uma conexao com o banco de dados
			conn = ConnectionFactory.createConnectiontoMySQL();
			
			//PreparedStatement criada para executar uma query
			pstm = (PreparedStatement) conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			//adicionar os valores que sao esperados pela query
			pstm.setString(1, cliente.getNome());
			pstm.setInt(2, cliente.getIdade());
			pstm.setDouble(3, cliente.getDinheiroNaConta());
		
			//Executar a query
			pstm.execute();
			
			try (ResultSet keys = pstm.getGeneratedKeys()) {
	            if (keys.next()) {

	                // resultado na coluna id_importacao.
	                id = keys.getInt(1);

	            }
	            else {
	                // Caso não haja uma chave a ser retornada lança um erro.
	                throw new SQLException("Nenhum id foi gerado.");
	            }
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				if(pstm != null) {
					pstm.close();
				}
				if(conn != null) {
					conn.close();
				}
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		}
        
        return id;
	}

	public List<Cliente> getClientes(){
		
		String sql = "SELECT * FROM cliente";
		
		List<Cliente> clientes = new ArrayList<Cliente>();
		
		Connection conn = null;
		PreparedStatement pstm = null;
	
		//Classe que vai recuperar os dados do banco. *SELECT*
		ResultSet rset = null;
		
		try {
			conn = ConnectionFactory.createConnectiontoMySQL();
			
			pstm = (PreparedStatement) conn.prepareStatement(sql);
			
			rset = pstm.executeQuery();
		
			while(rset.next()) {
				Cliente cliente = new Cliente(sql, 0, 0);
			
				//Recuperar o id
				cliente.setId(rset.getInt("id"));
				//Recuperar o nome
				cliente.setNome(rset.getString("nome"));
				//Recuperar a idade
				cliente.setIdade(rset.getInt("idade"));
				//Recuperar dinheiro na conta
				cliente.setDinheiroNaConta(rset.getDouble("dinheiroNaConta"));
				
				clientes.add(cliente);
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally {
			try {
				if(rset != null) {
					rset.close();
				}
				if(pstm != null) {
					pstm.close();
				}
				if(conn != null) {
					conn.close();
				}
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		
		}
		return clientes;
	}		

	public void update(Cliente cliente) {
		String sql = "UPDATE cliente SET dinheiroNaConta = ? WHERE id = ?";
		
		Connection conn = null;
		PreparedStatement pstm = null;
		
		try {
			//Criar uma conexao com o banco de dados
			conn = ConnectionFactory.createConnectiontoMySQL();
			
			//PreparedStatement criada para executar uma query
			pstm = (PreparedStatement) conn.prepareStatement(sql);
			//adicionar os valores que sao esperados pela query
			pstm.setDouble(1, cliente.getDinheiroNaConta());
			pstm.setInt(2, cliente.getId());
		
			//Executar a query
			pstm.execute();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				if(pstm != null) {
					pstm.close();
				}
				if(conn != null) {
					conn.close();
				}
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		}
	}
	
}
