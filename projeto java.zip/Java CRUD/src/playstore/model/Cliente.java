package playstore.model;

public class Cliente {
	private int id;
	private String nome;
	private int idade;
	private double dinheiroNaConta;
	private int jogoEscolhido;
	
	public Cliente(String nome, int idade, double dinheiroNaConta) {
		super();
		this.nome = nome;
		this.idade = idade;
		this.dinheiroNaConta = dinheiroNaConta;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}
	public double getDinheiroNaConta() {
		return dinheiroNaConta;
	}
	public void setDinheiroNaConta(double dinheiroNaConta) {
		this.dinheiroNaConta = dinheiroNaConta;
	}
	public int getJogoEscolhido() {
		return jogoEscolhido;
	}
	public void setJogoEscolhido(int jogoEscolhido) {
		this.jogoEscolhido = jogoEscolhido;
	}
	public void comprar(Jogo jogo) {
		double preco = jogo.getPreco();
		
		double novoSaldo = getDinheiroNaConta() - preco;
		
		setDinheiroNaConta(novoSaldo);
	}
	public void comprouJogo() {
		if(dinheiroNaConta >= 0) {
			System.out.println("Compra feita com sucesso! Novo dinheiro na conta = " + dinheiroNaConta);
		}
		else {
			System.out.println("Dinheiro insufisciente!");
		}
	}
}
